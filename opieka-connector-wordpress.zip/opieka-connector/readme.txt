=== Opieka Technical Connector ===
Contributors: indico
Requires at least: 6.5
Requires PHP: 8.1
Stable tag: 0.1.3
License: GPLv2 or later

Signed inventory, event and explicitly approved single-component update API for the Opieka techniczna system.

The plugin does not expose file access, SQL, arbitrary PHP execution or arbitrary package URLs. Configure the generated shared secret in Bitwarden Secrets Manager before enabling update scope.
