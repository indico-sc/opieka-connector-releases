=== Support Dj-Extensions Connector ===
Contributors: indico
Requires at least: 5.3
Requires PHP: 7.0
Stable tag: 0.1.13
Tested up to: 7.1
License: GPLv2 or later

Signed inventory, event and explicitly approved single-component update API for DJ-Extensions support.

The plugin does not expose file access, SQL, arbitrary PHP execution or arbitrary package URLs. Configure the generated shared secret in Bitwarden Secrets Manager before enabling update scope.

Compatibility includes WordPress 5.3 / PHP 7.0 and current WordPress / PHP releases. HTTPS, signed requests, nonce replay protection and explicit update scope remain required.

0.1.12 returns native installer failures as HTTP 422 with a sanitised explanation, preserving the cause through reverse proxies. Failed theme downloads retain the native upgrader skin error. It does not retry installations or alter update permissions.

0.1.7 adds frozen, signed WordPress Core updates through the connector, including native rollback and an exact post-update version check.

0.1.6 updates the connector's displayed name without changing its update identity, settings or API contract.

0.1.5 restores compatibility with WordPress 5.3 and PHP 7.0 without weakening connector authentication, signature verification or update authorization.

0.1.4 preserves event history on reactivation, loads filesystem functions for REST updates and uses the native one-item bulk upgrade path to preserve plugin activation.

0.1.13 preserves unknown YOOtheme download authorization as unverified instead of claiming the vendor key is missing. Native WordPress updater authorization and final installed-version verification remain authoritative.
