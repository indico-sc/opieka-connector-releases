<?php

defined('ABSPATH') || exit;

final class Opieka_Connector_Controller extends WP_REST_Controller
{
    protected $namespace = 'opieka/v1';

    public function register_routes(): void
    {
        register_rest_route($this->namespace, '/health', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'health'),
            'permission_callback' => static fn(WP_REST_Request $request) => Opieka_Connector_Auth::authorize($request, 'read'),
        ));
        register_rest_route($this->namespace, '/inventory', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'inventory'),
            'permission_callback' => static fn(WP_REST_Request $request) => Opieka_Connector_Auth::authorize($request, 'read'),
        ));
        register_rest_route($this->namespace, '/events', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'events'),
            'permission_callback' => static fn(WP_REST_Request $request) => Opieka_Connector_Auth::authorize($request, 'read'),
            'args' => array('after' => array('default' => 0, 'sanitize_callback' => 'absint')),
        ));
        register_rest_route($this->namespace, '/updates/refresh', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'refresh_updates'),
            'permission_callback' => static fn(WP_REST_Request $request) => Opieka_Connector_Auth::authorize($request, 'read'),
        ));
        register_rest_route($this->namespace, '/updates/execute', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'execute_update'),
            'permission_callback' => static fn(WP_REST_Request $request) => Opieka_Connector_Auth::authorize($request, 'update'),
        ));
    }

    private function envelope(array $data): WP_REST_Response
    {
        return new WP_REST_Response(array_merge(array(
            'protocolVersion' => '1.0',
            'connectorVersion' => OPIEKA_CONNECTOR_VERSION,
            'cms' => 'WordPress',
            'cmsVersion' => get_bloginfo('version'),
            'generatedAt' => gmdate('c'),
        ), $data), 200);
    }

    public function health(): WP_REST_Response
    {
        return $this->envelope(array(
            'status' => 'ok',
            'capabilities' => array('inventory', 'backup-profiles', 'events', 'refresh-updates', 'update-one'),
            'scopes' => array_values((array) get_option('opieka_connector_scopes', array('read'))),
            'keyFingerprint' => substr(hash('sha256', (string) get_option('opieka_connector_secret', '')), 0, 16),
        ));
    }

    public function inventory(): WP_REST_Response
    {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/update.php';
        wp_update_plugins();
        wp_update_themes();
        wp_version_check();
        $plugin_updates = get_site_transient('update_plugins');
        $theme_updates = get_site_transient('update_themes');
        $plugins = array();
        foreach (get_plugins() as $file => $plugin) {
            $offer = is_object($plugin_updates) && isset($plugin_updates->response[$file]) ? $plugin_updates->response[$file] : null;
            $plugins[] = array(
                'componentKey' => 'plugin:' . $file,
                'externalId' => $file,
                'name' => sanitize_text_field((string) ($plugin['Name'] ?? $file)),
                'type' => 'plugin',
                'version' => sanitize_text_field((string) ($plugin['Version'] ?? '')),
                'availableVersion' => $offer ? sanitize_text_field((string) ($offer->new_version ?? '')) : null,
                'updateAvailable' => (bool) $offer,
                'active' => is_plugin_active($file),
                'author' => sanitize_text_field(wp_strip_all_tags((string) ($plugin['AuthorName'] ?? $plugin['Author'] ?? ''))),
            );
        }
        $themes = array();
        foreach (wp_get_themes() as $slug => $theme) {
            $offer = is_object($theme_updates) && isset($theme_updates->response[$slug]) ? $theme_updates->response[$slug] : null;
            $themes[] = array(
                'componentKey' => 'theme:' . $slug,
                'externalId' => $slug,
                'name' => $theme->get('Name') ?: $slug,
                'type' => 'theme',
                'version' => (string) $theme->get('Version'),
                'availableVersion' => $offer ? sanitize_text_field((string) ($offer['new_version'] ?? '')) : null,
                'updateAvailable' => (bool) $offer,
                'active' => get_stylesheet() === $slug || get_template() === $slug,
                'author' => sanitize_text_field(wp_strip_all_tags((string) $theme->get('Author'))),
            );
        }
        $core = get_core_updates(array('dismissed' => false));
        $core_offer = is_array($core) ? current(array_filter($core, static fn($item) => isset($item->response) && $item->response === 'upgrade')) : false;
        global $wpdb;
        $profiles = array();
        $profile_table = '';
        foreach (array($wpdb->prefix . 'ak_profiles', $wpdb->prefix . 'akeebabackup_profiles') as $candidate_table) {
            if (preg_match('/^[A-Za-z0-9_]+$/', $candidate_table)
                && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $candidate_table)) === $candidate_table) {
                $profile_table = $candidate_table;
                break;
            }
        }
        if ($profile_table !== '') {
            $profile_rows = $wpdb->get_results("SELECT id, description FROM `{$profile_table}` ORDER BY id", ARRAY_A); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- trusted table prefix plus fixed allowlisted suffix, validated above.
            foreach ((array) $profile_rows as $profile) {
                $profiles[] = array(
                    'externalId' => (string) absint($profile['id'] ?? 0),
                    'name' => sanitize_text_field((string) ($profile['description'] ?? '')) ?: 'Akeeba profile ' . absint($profile['id'] ?? 0),
                    'isDefault' => absint($profile['id'] ?? 0) === 1,
                );
            }
        }
        return $this->envelope(array(
            'environment' => array(
                'php' => PHP_VERSION,
                'database' => $GLOBALS['wpdb']->db_version(),
                'webServer' => sanitize_text_field((string) ($_SERVER['SERVER_SOFTWARE'] ?? '')),
                'siteUrl' => site_url('/'),
                'homeUrl' => home_url('/'),
                'multisite' => is_multisite(),
            ),
            'core' => array('version' => get_bloginfo('version'), 'availableVersion' => $core_offer ? (string) $core_offer->current : null, 'updateAvailable' => (bool) $core_offer),
            'extensions' => array_merge($plugins, $themes),
            'backup' => array('profiles' => $profiles),
        ));
    }

    public function events(WP_REST_Request $request): WP_REST_Response
    {
        $after = absint($request->get_param('after'));
        $events = array_values(array_filter((array) get_option('opieka_connector_events', array()), static fn($event) => (int) ($event['cursor'] ?? 0) > $after));
        return $this->envelope(array('events' => array_slice($events, 0, 200), 'nextCursor' => $events ? (int) end($events)['cursor'] : $after));
    }

    public function refresh_updates(): WP_REST_Response
    {
        require_once ABSPATH . 'wp-admin/includes/update.php';
        wp_update_plugins();
        wp_update_themes();
        wp_version_check();
        self::record_event('updates.refreshed', array());
        return $this->envelope(array('status' => 'completed'));
    }

    public function execute_update(WP_REST_Request $request)
    {
        $payload = $request->get_json_params();
        $operation_id = sanitize_text_field((string) ($payload['operationId'] ?? ''));
        $kind = sanitize_key((string) ($payload['kind'] ?? ''));
        $component_key = sanitize_text_field((string) ($payload['componentKey'] ?? ''));
        $expected = sanitize_text_field((string) ($payload['expectedCurrentVersion'] ?? ''));
        $target = sanitize_text_field((string) ($payload['targetVersion'] ?? ''));
        if (!preg_match('/^[A-Za-z0-9._:-]{12,120}$/', $operation_id)
            || !in_array($kind, array('plugin', 'theme', 'core'), true)
            || $component_key === '' || $expected === '' || $target === '') {
            return new WP_Error('opieka_update_invalid', 'Invalid frozen update operation.', array('status' => 400));
        }
        $operations = (array) get_option('opieka_connector_operations', array());
        if (isset($operations[$operation_id])) {
            return $this->envelope(array('status' => 'idempotent-replay', 'operation' => $operations[$operation_id]));
        }
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/update.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        wp_update_plugins();
        wp_update_themes();
        wp_version_check();
        $result = null;
        if ($kind === 'plugin') {
            $file = str_starts_with($component_key, 'plugin:') ? substr($component_key, 7) : $component_key;
            $plugins = get_plugins();
            $updates = get_site_transient('update_plugins');
            $current = sanitize_text_field((string) ($plugins[$file]['Version'] ?? ''));
            $offered = is_object($updates) && isset($updates->response[$file]) ? sanitize_text_field((string) ($updates->response[$file]->new_version ?? '')) : '';
            if ($current !== $expected || $offered !== $target) {
                return new WP_Error('opieka_update_conflict', 'Live plugin state differs from the approved operation.', array('status' => 409, 'currentVersion' => $current, 'offeredVersion' => $offered));
            }
            $result = (new Plugin_Upgrader(new Automatic_Upgrader_Skin()))->upgrade($file, array('clear_update_cache' => true));
        } elseif ($kind === 'theme') {
            $slug = str_starts_with($component_key, 'theme:') ? substr($component_key, 6) : $component_key;
            $theme = wp_get_theme($slug);
            $updates = get_site_transient('update_themes');
            $current = $theme->exists() ? (string) $theme->get('Version') : '';
            $offered = is_object($updates) && isset($updates->response[$slug]) ? sanitize_text_field((string) ($updates->response[$slug]['new_version'] ?? '')) : '';
            if ($current !== $expected || $offered !== $target) {
                return new WP_Error('opieka_update_conflict', 'Live theme state differs from the approved operation.', array('status' => 409, 'currentVersion' => $current, 'offeredVersion' => $offered));
            }
            $result = (new Theme_Upgrader(new Automatic_Upgrader_Skin()))->upgrade($slug, array('clear_update_cache' => true));
        } else {
            if (explode('.', $expected)[0] !== explode('.', $target)[0]) {
                return new WP_Error('opieka_manual_migration_required', 'Core release-line migrations require a human-controlled process.', array('status' => 409));
            }
            return new WP_Error('opieka_core_manual_required', 'WordPress Core updates remain a separate human-controlled operation in connector v1.', array('status' => 409));
        }
        if (is_wp_error($result)) {
            return new WP_Error('opieka_update_failed', $result->get_error_message(), array('status' => 502));
        }
        if ($result !== true) {
            return new WP_Error('opieka_update_unconfirmed', 'WordPress did not confirm the update.', array('status' => 502));
        }
        $record = array('operationId' => $operation_id, 'kind' => $kind, 'componentKey' => $component_key, 'fromVersion' => $expected, 'toVersion' => $target, 'status' => 'completed', 'completedAt' => gmdate('c'));
        $operations[$operation_id] = $record;
        if (count($operations) > 100) {
            $operations = array_slice($operations, -100, null, true);
        }
        update_option('opieka_connector_operations', $operations, false);
        self::record_event('update.completed', $record);
        return $this->envelope(array('status' => 'completed', 'operation' => $record));
    }

    public static function record_event(string $type, array $data): void
    {
        $events = (array) get_option('opieka_connector_events', array());
        $cursor = $events ? ((int) end($events)['cursor'] + 1) : 1;
        $events[] = array('cursor' => $cursor, 'type' => sanitize_key(str_replace('.', '-', $type)), 'occurredAt' => gmdate('c'), 'data' => $data);
        update_option('opieka_connector_events', array_slice($events, -200), false);
    }
}
