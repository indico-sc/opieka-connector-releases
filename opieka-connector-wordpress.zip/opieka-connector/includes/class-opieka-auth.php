<?php

defined('ABSPATH') || exit;

final class Opieka_Connector_Auth
{
    private const CLOCK_SKEW = 300;

    public static function authorize(WP_REST_Request $request, string $scope)
    {
        if (!is_ssl()) {
            return new WP_Error('opieka_https_required', 'Connector requests require HTTPS.', array('status' => 403));
        }
        $key = trim((string) $request->get_header('x-opieka-key'));
        $timestamp = trim((string) $request->get_header('x-opieka-timestamp'));
        $nonce = trim((string) $request->get_header('x-opieka-nonce'));
        $body_hash = strtolower(trim((string) $request->get_header('x-opieka-content-sha256')));
        $signature = strtolower(trim((string) $request->get_header('x-opieka-signature')));
        if (!hash_equals((string) get_option('opieka_connector_key_id', ''), $key)
            || !preg_match('/^\d{10}$/', $timestamp)
            || !preg_match('/^[A-Za-z0-9_-]{20,120}$/', $nonce)
            || !preg_match('/^[a-f0-9]{64}$/', $body_hash)
            || !preg_match('/^[a-f0-9]{64}$/', $signature)) {
            return new WP_Error('opieka_auth_invalid', 'Invalid connector authentication headers.', array('status' => 401));
        }
        if (abs(time() - (int) $timestamp) > self::CLOCK_SKEW) {
            return new WP_Error('opieka_auth_expired', 'Connector request timestamp is outside the allowed window.', array('status' => 401));
        }
        $raw_body = (string) $request->get_body();
        if (!hash_equals(hash('sha256', $raw_body), $body_hash)) {
            return new WP_Error('opieka_body_mismatch', 'Connector request body hash does not match.', array('status' => 401));
        }
        $nonce_key = 'opieka_nonce_' . hash('sha256', $key . ':' . $nonce);
        if (get_transient($nonce_key)) {
            return new WP_Error('opieka_replay', 'Connector nonce has already been used.', array('status' => 409));
        }
        $secret = (string) get_option('opieka_connector_secret', '');
        $canonical = strtoupper($request->get_method()) . "\n" . $request->get_route() . "\n" . $timestamp . "\n" . $nonce . "\n" . $body_hash;
        if (strlen($secret) < 32 || !hash_equals(hash_hmac('sha256', $canonical, $secret), $signature)) {
            return new WP_Error('opieka_signature_invalid', 'Invalid connector signature.', array('status' => 401));
        }
        $scopes = (array) get_option('opieka_connector_scopes', array('read'));
        if (!in_array($scope, $scopes, true)) {
            return new WP_Error('opieka_scope_denied', 'Connector scope is disabled.', array('status' => 403));
        }
        set_transient($nonce_key, '1', self::CLOCK_SKEW * 2);
        return true;
    }
}
