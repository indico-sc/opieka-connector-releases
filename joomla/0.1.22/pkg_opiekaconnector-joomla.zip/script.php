<?php

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseInterface;
use Joomla\Registry\Registry;

if (!class_exists(Factory::class) && class_exists('JFactory')) {
    class_alias('JFactory', Factory::class);
}
if (!class_exists(Registry::class) && class_exists('JRegistry')) {
    class_alias('JRegistry', Registry::class);
}
if (!class_exists(Table::class) && class_exists('JTable')) {
    class_alias('JTable', Table::class);
}

class pkg_opiekaconnectorInstallerScript {
    public function install($parent): bool
    {
        return true;
    }

    public function update($parent): bool
    {
        return true;
    }

    public function uninstall($parent): bool
    {
        return true;
    }

    public function preflight($type, $parent): bool
    {
        if ($type !== 'uninstall' && (version_compare(PHP_VERSION, '7.4', '<') || version_compare(JVERSION, '3.0', '<'))) {
            Factory::getApplication()->enqueueMessage('Support Dj-Extensions Connector requires Joomla 3+ and PHP 7.4+.', 'error');
            return false;
        }
        return true;
    }

    public function postflight($type, $parent): bool
    {
        if ($type === 'uninstall') {
            return true;
        }

        try {
            $db = version_compare(JVERSION, '4.0', '<') ? JFactory::getDbo() : Factory::getContainer()->get(DatabaseInterface::class);
            $this->ensureSchema($db);
            $this->removeMisidentifiedComponentDuplicates($db);
            $pluginType = 'plugin';
            $systemFolder = 'system';
            $connectorElement = 'opiekaconnector';
            $query = $db->getQuery(true)
                ->select([$db->quoteName('extension_id'), $db->quoteName('params')])
                ->from($db->quoteName('#__extensions'))
                ->where($db->quoteName('type') . ' = ' . $db->quote($pluginType))
                ->where($db->quoteName('folder') . ' = ' . $db->quote($systemFolder))
                ->where($db->quoteName('element') . ' = ' . $db->quote($connectorElement));
            $extension = $db->setQuery($query)->loadObject();
            if (!$extension) {
                throw new RuntimeException('The System - Support Dj-Extensions Connector plugin record was not created.');
            }

            $pluginType = 'plugin';
            $connectorElement = 'opiekaconnector';
            $pluginFolders = ['system', 'webservices'];
            $enable = $db->getQuery(true)
                ->update($db->quoteName('#__extensions'))
                ->set($db->quoteName('enabled') . ' = 1')
                ->where($db->quoteName('type') . ' = ' . $db->quote($pluginType))
                ->where($db->quoteName('element') . ' = ' . $db->quote($connectorElement))
                ->where($db->quoteName('folder') . " IN ('system','webservices')");
            $db->setQuery($enable)->execute();

            $params = new Registry((string) $extension->params);
            $keyId = trim((string) $params->get('key_id', ''));
            $secret = (string) $params->get('secret', '');
            $changed = false;
            if ($keyId === '') {
                $params->set('key_id', 'opk_' . bin2hex(random_bytes(12)));
                $changed = true;
            }
            if (strlen($secret) < 32) {
                $params->set('secret', rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '='));
                $changed = true;
            }
            $requiredScopes = ['read', 'update'];
            $configuredScopes = $params->get('scopes', []);
            $configuredScopes = is_array($configuredScopes)
                ? $configuredScopes
                : preg_split('/\s*,\s*/', (string) $configuredScopes, -1, PREG_SPLIT_NO_EMPTY);
            $configuredScopes = array_values(array_unique(array_filter(array_map(
                static fn($scope): string => trim((string) $scope),
                $configuredScopes ?: []
            ))));
            if ($configuredScopes !== $requiredScopes) {
                $params->set('scopes', $requiredScopes);
                $changed = true;
            }
            if (!$changed) return true;

            $extensionId = (int) $extension->extension_id;
            $encodedParams = $params->toString('JSON');
            $update = $db->getQuery(true)
                ->update($db->quoteName('#__extensions'))
                ->set($db->quoteName('params') . ' = ' . $db->quote($encodedParams))
                ->where($db->quoteName('extension_id') . ' = ' . (int) $extensionId);
            $db->setQuery($update)->execute();

            return true;
        } catch (Throwable $error) {
            Factory::getApplication()->enqueueMessage(
                'Support Dj-Extensions Connector could not initialise its API credentials: ' . $error->getMessage(),
                'error'
            );

            return false;
        }
    }

    private function ensureSchema($db): void
    {
        $queries = [
            "CREATE TABLE IF NOT EXISTS `#__opiekaconnector_events` (
                `id` bigint unsigned NOT NULL AUTO_INCREMENT,
                `event_type` varchar(100) NOT NULL,
                `payload` mediumtext NOT NULL,
                `created_at` datetime NOT NULL,
                PRIMARY KEY (`id`),
                KEY `idx_opieka_event_created` (`created_at`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS `#__opiekaconnector_operations` (
                `operation_id` varchar(120) NOT NULL,
                `component_key` varchar(255) NOT NULL,
                `result` mediumtext NOT NULL,
                `created_at` datetime NOT NULL,
                PRIMARY KEY (`operation_id`),
                KEY `idx_opieka_operation_created` (`created_at`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS `#__opiekaconnector_nonces` (
                `nonce_hash` char(64) NOT NULL,
                `expires_at` datetime NOT NULL,
                PRIMARY KEY (`nonce_hash`),
                KEY `idx_opieka_nonce_expires` (`expires_at`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci",
        ];

        foreach ($queries as $query) {
            $db->setQuery($query)->execute();
        }
    }

    private function removeMisidentifiedComponentDuplicates($db): void
    {
        $componentType = 'component';
        $canonicalElement = 'com_opiekaconnector';
        $canonical = $db->setQuery(
            $db->getQuery(true)
                ->select([$db->quoteName('extension_id'), $db->quoteName('package_id')])
                ->from($db->quoteName('#__extensions'))
                ->where($db->quoteName('type') . ' = ' . $db->quote($componentType))
                ->where($db->quoteName('element') . ' = ' . $db->quote($canonicalElement))
        )->loadObject();

        if (!$canonical || (int) $canonical->package_id <= 0) {
            throw new RuntimeException('The canonical Support Dj-Extensions Connector component record is missing.');
        }

        $candidates = $db->setQuery(
            $db->getQuery(true)
                ->select([
                    $db->quoteName('extension_id'),
                    $db->quoteName('element'),
                    $db->quoteName('name'),
                    $db->quoteName('manifest_cache'),
                ])
                ->from($db->quoteName('#__extensions'))
                ->where($db->quoteName('type') . ' = ' . $db->quote($componentType))
                ->where($db->quoteName('package_id') . ' = ' . (int) $canonical->package_id)
                ->where($db->quoteName('extension_id') . ' != ' . (int) $canonical->extension_id)
        )->loadObjectList();

        foreach ($candidates as $candidate) {
            $manifest = json_decode((string) $candidate->manifest_cache, true);
            if (
                (string) $candidate->name !== 'Support Dj-Extensions Connector'
                || !is_array($manifest)
                || (string) ($manifest['version'] ?? '') !== '0.1.20'
            ) {
                continue;
            }

            $duplicateId = (int) $candidate->extension_id;
            $duplicateElement = (string) $candidate->element;
            foreach ([
                ['#__menu', 'component_id', $duplicateId],
                ['#__schemas', 'extension_id', $duplicateId],
                ['#__updates', 'extension_id', $duplicateId],
                ['#__update_sites_extensions', 'extension_id', $duplicateId],
            ] as $reference) {
                $db->setQuery(
                    $db->getQuery(true)
                        ->delete($db->quoteName($reference[0]))
                        ->where($db->quoteName($reference[1]) . ' = ' . (int) $reference[2])
                )->execute();
            }
            if ($duplicateElement !== '' && $duplicateElement !== $canonicalElement) {
                $asset = Table::getInstance('Asset');
                if ($asset->loadByName($duplicateElement)) {
                    $asset->delete();
                }
            }
            $db->setQuery(
                $db->getQuery(true)
                    ->delete($db->quoteName('#__extensions'))
                    ->where($db->quoteName('extension_id') . ' = ' . $duplicateId)
            )->execute();
        }
    }
}
