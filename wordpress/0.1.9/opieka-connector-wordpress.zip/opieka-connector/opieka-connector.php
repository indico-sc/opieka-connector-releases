<?php
/**
 * Plugin Name: Support Dj-Extensions Connector
 * Description: Signed, least-privilege inventory and update API for DJ-Extensions support.
 * Version: 0.1.9
 * Update URI: https://indico-sc.github.io/opieka-connector-releases/wordpress
 * Requires at least: 5.3
 * Requires PHP: 7.0
 * Author: Indico
 * License: GPL-2.0-or-later
 * Text Domain: opieka-connector
 */

defined('ABSPATH') || exit;

define('OPIEKA_CONNECTOR_VERSION', '0.1.9');
define('OPIEKA_CONNECTOR_FILE', __FILE__);
define('OPIEKA_CONNECTOR_UPDATE_MANIFEST_URL', 'https://indico-sc.github.io/opieka-connector-releases/manifest.json');
define('OPIEKA_CONNECTOR_UPDATE_PUBLIC_KEY', 'CCdcPtwrhayJsHdpgwtDg/xWwZ3KGzGG8VVnhzA+7zs=');

require_once __DIR__ . '/includes/class-opieka-auth.php';
require_once __DIR__ . '/includes/class-opieka-controller.php';
require_once __DIR__ . '/includes/class-opieka-update-stream.php';

Opieka_Connector_Update_Stream::register();

register_activation_hook(__FILE__, static function () {
    if (!get_option('opieka_connector_key_id')) {
        update_option('opieka_connector_key_id', 'opk_' . wp_generate_password(20, false, false), false);
    }
    if (!get_option('opieka_connector_secret')) {
        update_option('opieka_connector_secret', rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '='), false);
    }
    if (!get_option('opieka_connector_scopes')) {
        update_option('opieka_connector_scopes', array('read'), false);
    }
    add_option('opieka_connector_events', array(), '', false);
    add_option('opieka_connector_operations', array(), '', false);
});

add_action('rest_api_init', static function () {
    (new Opieka_Connector_Controller())->register_routes();
});

add_action('upgrader_process_complete', static function ($upgrader, array $hook_extra) {
    Opieka_Connector_Controller::record_event('cms.upgrader.completed', array(
        'action' => sanitize_key((string) ($hook_extra['action'] ?? '')),
        'type' => sanitize_key((string) ($hook_extra['type'] ?? '')),
        'plugins' => array_map('sanitize_text_field', (array) ($hook_extra['plugins'] ?? array())),
        'themes' => array_map('sanitize_text_field', (array) ($hook_extra['themes'] ?? array())),
    ));
}, 10, 2);

add_action('admin_menu', static function () {
    add_management_page('Support Dj-Extensions Connector', 'Support Dj-Extensions Connector', 'manage_options', 'opieka-connector', 'opieka_connector_settings_page');
});

function opieka_connector_settings_page()
{
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Insufficient permissions.', 'opieka-connector'));
    }
    $revealed_secret = '';
    if (isset($_POST['opieka_connector_save'])) {
        check_admin_referer('opieka_connector_settings');
        $action = sanitize_key((string) ($_POST['opieka_connector_action'] ?? 'save'));
        $scopes = array('read');
        if (!empty($_POST['scope_update'])) {
            $scopes[] = 'update';
        }
        update_option('opieka_connector_scopes', $scopes, false);
        if ($action === 'rotate') {
            update_option('opieka_connector_secret', rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '='), false);
            update_option('opieka_connector_key_id', 'opk_' . wp_generate_password(20, false, false), false);
        }
        if ($action === 'reveal' || $action === 'rotate') {
            $revealed_secret = (string) get_option('opieka_connector_secret', '');
        }
        $message = $action === 'rotate'
            ? __('Key ID and Shared HMAC Secret were rotated. Update Bitwarden before running another API operation.', 'opieka-connector')
            : __('Connector settings saved.', 'opieka-connector');
        echo '<div class="notice notice-success"><p>' . esc_html($message) . '</p></div>';
    }
    $secret = (string) get_option('opieka_connector_secret', '');
    $scopes = (array) get_option('opieka_connector_scopes', array('read'));
    ?>
    <div class="wrap">
        <h1>Support Dj-Extensions Connector</h1>
        <table class="widefat striped" style="max-width: 900px"><tbody>
            <tr><th scope="row"><?php esc_html_e('Endpoint', 'opieka-connector'); ?></th><td><code><?php echo esc_html(rest_url('opieka/v1/')); ?></code></td></tr>
            <tr><th scope="row"><?php esc_html_e('Key ID', 'opieka-connector'); ?></th><td><code><?php echo esc_html((string) get_option('opieka_connector_key_id', '')); ?></code></td></tr>
            <tr><th scope="row"><?php esc_html_e('Secret fingerprint', 'opieka-connector'); ?></th><td><code><?php echo esc_html(substr(hash('sha256', $secret), 0, 16)); ?></code></td></tr>
        </tbody></table>
        <p><?php esc_html_e('The full Shared HMAC Secret is masked by default. Reveal it only to copy it into the controlled Bitwarden connector form.', 'opieka-connector'); ?></p>
        <?php if ($revealed_secret !== '') : ?>
            <div class="notice notice-warning inline"><p><strong><?php esc_html_e('Full Shared HMAC Secret — copy now to the support panel:', 'opieka-connector'); ?></strong></p><p><input type="text" class="large-text code" readonly value="<?php echo esc_attr($revealed_secret); ?>" onfocus="this.select()"></p><p><?php esc_html_e('Leave this page after copying. The value is never returned by the connector API.', 'opieka-connector'); ?></p></div>
        <?php endif; ?>
        <form method="post">
            <?php wp_nonce_field('opieka_connector_settings'); ?>
            <label><input type="checkbox" name="scope_update" value="1" <?php checked(in_array('update', $scopes, true)); ?>> <?php esc_html_e('Allow explicitly approved updates', 'opieka-connector'); ?></label>
            <p class="submit">
                <button class="button button-primary" name="opieka_connector_save" value="1"><?php esc_html_e('Save settings', 'opieka-connector'); ?></button>
                <button class="button" name="opieka_connector_action" value="reveal"><?php esc_html_e('Reveal full Shared HMAC Secret', 'opieka-connector'); ?></button>
                <button class="button" name="opieka_connector_action" value="rotate" onclick="return confirm('<?php echo esc_js(__('Rotate Key ID and Shared HMAC Secret? Existing API connections will stop until Bitwarden is updated.', 'opieka-connector')); ?>')"><?php esc_html_e('Rotate Key ID and secret', 'opieka-connector'); ?></button>
                <input type="hidden" name="opieka_connector_save" value="1">
            </p>
        </form>
    </div>
    <?php
}
