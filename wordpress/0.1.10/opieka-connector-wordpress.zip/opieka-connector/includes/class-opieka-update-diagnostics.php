<?php
// Shared implementation; the Joomla package carries an identical copy.
final class Opieka_Update_Diagnostics
{
    const VERSION = '1.0';
    const RETENTION_DAYS = 14;
    const WINDOW_LIMIT = 200;
    const PHASES = ['accepted', 'metadata-refresh', 'live-state-check', 'filesystem', 'download', 'unpack', 'install', 'post-install-verification', 'cache-refresh', 'completed'];
    private $sink;
    private $operationId;
    private $componentKey;
    private $executionId;
    private $started;
    private $phaseStarted;
    private $phase = 'accepted';
    private $sequence = 0;
    private $httpCount = 0;
    private $closed = false;
    private $httpStatus = null;
    private $downloadHost = null;
    private $reserve;

    public function __construct($operationId, $componentKey, callable $sink)
    {
        $this->operationId = $operationId;
        $this->componentKey = preg_match('#^(?:plugin:[A-Za-z0-9._/-]{1,180}|theme:[A-Za-z0-9_-]{1,100}|core:(?:wordpress|joomla)|update:[0-9]{1,12})$#D', $componentKey) ? $componentKey : 'unknown';
        $this->executionId = bin2hex(random_bytes(8));
        $this->sink = $sink;
        $this->started = $this->phaseStarted = microtime(true);
        // Leave enough memory to persist a small receipt after PHP exhausts memory.
        $this->reserve = str_repeat(' ', 65536);
        register_shutdown_function([$this, 'shutdown']);
        $this->write('running');
    }

    public function phase($phase)
    {
        if ($this->closed || $phase === $this->phase || !in_array($phase, self::PHASES, true)) {
            return;
        }
        $this->phase = $phase;
        $this->phaseStarted = microtime(true);
        if ($this->sequence < 24) { $this->write('running'); }
    }

    public function http($status, $url, $errorCode = '')
    {
        if ($this->closed) { return; }
        $this->httpStatus = is_int($status) && $status >= 100 && $status <= 599 ? $status : null;
        $host = parse_url((string) $url, PHP_URL_HOST);
        $this->downloadHost = is_string($host) && strlen($host) <= 253 && preg_match('/^[A-Za-z0-9.-]+$/D', $host) ? strtolower($host) : null;
        if ($this->sequence < 24 && (++$this->httpCount <= 8 || $this->httpStatus >= 400 || $errorCode !== '')) { $this->write('running', $errorCode); }
    }

    public function finish($status, $errorCode = '', $message = '')
    {
        if ($this->closed) { return; }
        if (!in_array($status, ['completed', 'failed', 'rejected', 'interrupted'], true)) { $status = 'failed'; }
        $this->reserve = null;
        $this->closed = true;
        if ($status === 'completed') { $this->phase = 'completed'; }
        $this->write($status, $errorCode, $message);
    }

    public function shutdown()
    {
        if ($this->closed) { return; }
        $error = error_get_last();
        $fatal = is_array($error) && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR], true);
        // No exception arguments, source paths, request bodies or raw PHP errors.
        $this->finish('interrupted', $fatal ? 'php_fatal' : 'php_shutdown_unconfirmed', $fatal ? 'PHP terminated with a fatal error.' : 'PHP ended without an installation receipt.');
    }

    public static function safeMessage($value)
    {
        $text = html_entity_decode(strip_tags((string) $value), ENT_QUOTES, 'UTF-8');
        $text = preg_replace('/\b(?:Bearer|Basic)\s+[A-Za-z0-9._~+\/=\-]+/i', '[redacted]', $text);
        $text = preg_replace('#https?://[^\s<>"\x27]+#i', '[url]', $text);
        $text = preg_replace('/\b(?:authorization|password|passwd|secret|token|cookie|api[_ -]?key|download[_ -]?id|license[_ -]?key)\b\s*[:=]?\s*(?:"[^"]*"|\x27[^\x27]*\x27|[^\s,;]+)/i', '[redacted]', $text);
        $text = preg_replace('#(?:[A-Za-z]:[\\\\/]|/)(?:[^\s<>"\x27()]+[/\\\\])+[^\s<>"\x27()]*#', '[path]', $text);
        $text = preg_replace('/\b[A-Za-z0-9_+\/=.-]{32,}\b/', '[redacted]', $text);
        $text = preg_replace('/[\x00-\x1f\x7f]+/', ' ', $text);
        $text = trim(preg_replace('/\s+/', ' ', $text));
        return function_exists('mb_substr') ? mb_substr($text, 0, 300, 'UTF-8') : substr($text, 0, 300);
    }

    private function write($status, $errorCode = '', $message = '')
    {
        $now = microtime(true);
        $row = [
            'executionId' => $this->executionId,
            'sequence' => ++$this->sequence,
            'operationId' => $this->operationId,
            'componentKey' => $this->componentKey,
            'phase' => $this->phase,
            'status' => $status,
            'occurredAt' => gmdate('c'),
            'elapsedMs' => min(2147483647, max(0, (int) round(($now - $this->started) * 1000))),
            'durationMs' => min(2147483647, max(0, (int) round(($now - $this->phaseStarted) * 1000))),
            'errorCode' => is_string($errorCode) && preg_match('/^[A-Za-z0-9_.:-]{0,120}$/D', $errorCode) ? $errorCode : 'native_error',
            'message' => self::safeMessage($message),
            'httpStatus' => $this->httpStatus,
            'downloadHost' => $this->downloadHost,
            'phpVersion' => PHP_VERSION,
            'peakMemoryBytes' => min(2147483647, memory_get_peak_usage(true)),
        ];
        try { call_user_func($this->sink, $row); }
        catch (\Throwable $error) {
            // A diagnostics failure never changes the installation result.
            error_log('OPIEKA_DIAGNOSTIC ' . json_encode($row, JSON_UNESCAPED_SLASHES));
        }
    }
}
