<?php

defined('ABSPATH') || exit;

final class Opieka_Connector_Update_Stream
{
    const MAX_MANIFEST_BYTES = 262144;

    public static function register()
    {
        $host = wp_parse_url(OPIEKA_CONNECTOR_UPDATE_MANIFEST_URL, PHP_URL_HOST);
        if (!is_string($host) || $host === '' || $host === 'updates.invalid') {
            return;
        }
        if (version_compare((string) get_bloginfo('version'), '5.8', '<')) {
            add_filter('pre_set_site_transient_update_plugins', array(self::class, 'check_legacy_update'));
        } else {
            add_filter('update_plugins_' . $host, array(self::class, 'check_update'), 10, 4);
        }
        add_filter('upgrader_pre_download', array(self::class, 'verify_download'), 10, 4);
        add_filter('auto_update_plugin', array(self::class, 'disable_auto_update'), 10, 2);
    }

    public static function disable_auto_update($update, $item)
    {
        $plugin = is_object($item) ? ($item->plugin ?? '') : (is_array($item) ? ($item['plugin'] ?? '') : '');
        return $plugin === plugin_basename(OPIEKA_CONNECTOR_FILE) ? false : $update;
    }

    public static function check_update($update, array $plugin_data, string $plugin_file, array $locales)
    {
        unset($plugin_data, $locales);
        if ($plugin_file !== plugin_basename(OPIEKA_CONNECTOR_FILE)) {
            return $update;
        }
        $release = self::trusted_release();
        if (is_wp_error($release) || version_compare(OPIEKA_CONNECTOR_VERSION, $release['version'], '>=')) {
            return $update;
        }
        return array(
            'id' => dirname(OPIEKA_CONNECTOR_UPDATE_MANIFEST_URL) . '/wordpress',
            'slug' => 'opieka-connector',
            'plugin' => $plugin_file,
            'version' => $release['version'],
            'new_version' => $release['version'],
            'url' => dirname(OPIEKA_CONNECTOR_UPDATE_MANIFEST_URL) . '/wordpress',
            'package' => $release['packageUrl'],
            'requires_php' => '7.0',
            'requires' => '5.3',
            'autoupdate' => false,
        );
    }

    public static function check_legacy_update($transient)
    {
        if (!is_object($transient)) {
            return $transient;
        }
        $plugin_file = plugin_basename(OPIEKA_CONNECTOR_FILE);
        $update = self::check_update(false, array(), $plugin_file, array());
        if (is_array($update)) {
            $transient->response[$plugin_file] = (object) $update;
            if (isset($transient->no_update[$plugin_file])) {
                unset($transient->no_update[$plugin_file]);
            }
        }
        return $transient;
    }

    public static function verify_download($reply, string $package, $upgrader, array $hook_extra)
    {
        unset($upgrader);
        if ($reply !== false || ($hook_extra['type'] ?? '') !== 'plugin' || ($hook_extra['action'] ?? '') !== 'update') {
            return $reply;
        }
        $plugins = array_map('strval', (array) ($hook_extra['plugins'] ?? array($hook_extra['plugin'] ?? '')));
        if (!in_array(plugin_basename(OPIEKA_CONNECTOR_FILE), $plugins, true)) {
            return $reply;
        }
        $release = self::trusted_release();
        if (is_wp_error($release) || !hash_equals($release['packageUrl'], $package)) {
            return new WP_Error('opieka_update_untrusted', __('Opieka Connector update package is not present in the trusted signed manifest.', 'opieka-connector'));
        }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        $temporary = download_url($package, 30, false);
        if (is_wp_error($temporary)) {
            return $temporary;
        }
        $size = filesize($temporary);
        $sha256 = hash_file('sha256', $temporary);
        if ($size !== $release['size'] || !is_string($sha256) || !hash_equals($release['sha256'], $sha256)) {
            wp_delete_file($temporary);
            return new WP_Error('opieka_update_checksum', __('Opieka Connector package checksum or size does not match the signed manifest.', 'opieka-connector'));
        }
        return $temporary;
    }

    private static function trusted_release()
    {
        if (!extension_loaded('sodium') || OPIEKA_CONNECTOR_UPDATE_PUBLIC_KEY === '') {
            return new WP_Error('opieka_update_disabled', 'Update verification is not configured.');
        }
        $response = wp_safe_remote_get(OPIEKA_CONNECTOR_UPDATE_MANIFEST_URL, array(
            'timeout' => 10,
            'redirection' => 0,
            'limit_response_size' => self::MAX_MANIFEST_BYTES,
            'headers' => array('Accept' => 'application/json'),
        ));
        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
            return new WP_Error('opieka_update_manifest', 'The signed update manifest is unavailable.');
        }
        $raw = wp_remote_retrieve_body($response);
        if (strlen($raw) > self::MAX_MANIFEST_BYTES) {
            return new WP_Error('opieka_update_manifest_size', 'The update manifest exceeds the size limit.');
        }
        $manifest = json_decode($raw, true);
        $signature = is_array($manifest) ? ($manifest['signature'] ?? null) : null;
        if (!is_array($manifest) || !is_array($signature) || ($signature['algorithm'] ?? '') !== 'ed25519') {
            return new WP_Error('opieka_update_signature', 'The update manifest signature is invalid.');
        }
        unset($manifest['signature']);
        $public_key = base64_decode(OPIEKA_CONNECTOR_UPDATE_PUBLIC_KEY, true);
        $signature_bytes = base64_decode((string) ($signature['value'] ?? ''), true);
        if (!is_string($public_key) || strlen($public_key) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES || !is_string($signature_bytes)) {
            return new WP_Error('opieka_update_key', 'The update verification key is invalid.');
        }
        try {
            $valid = sodium_crypto_sign_verify_detached($signature_bytes, self::canonical_json($manifest), $public_key);
        } catch (Throwable $error) {
            return new WP_Error('opieka_update_signature', 'The update manifest signature cannot be verified.');
        }
        if (!$valid || ($manifest['schemaVersion'] ?? null) !== 1 || ($manifest['channel'] ?? '') !== 'stable' || ($manifest['operatorInitiatedOnly'] ?? null) !== true) {
            return new WP_Error('opieka_update_policy', 'The update manifest does not satisfy the connector policy.');
        }
        $generated = strtotime((string) ($manifest['generatedAt'] ?? ''));
        $expires = strtotime((string) ($manifest['expiresAt'] ?? ''));
        if ($generated === false || $generated > time() + 300 || $expires === false || $expires <= time() || $expires <= $generated) {
            return new WP_Error('opieka_update_expired', 'The update manifest has expired.');
        }
        $matches = array_values(array_filter((array) ($manifest['releases'] ?? array()), static function ($release): bool {
            return is_array($release) && ($release['cms'] ?? '') === 'WordPress' && ($release['protocolVersion'] ?? '') === '1.0';
        }));
        if (count($matches) !== 1 || !self::valid_release($matches[0])) {
            return new WP_Error('opieka_update_release', 'The manifest does not contain exactly one valid WordPress release.');
        }
        return $matches[0];
    }

    private static function valid_release(array $release): bool
    {
        $url = (string) ($release['packageUrl'] ?? '');
        return preg_match('/^\d+\.\d+\.\d+$/', (string) ($release['version'] ?? '')) === 1
            && wp_http_validate_url($url) !== false
            && strtolower((string) wp_parse_url($url, PHP_URL_SCHEME)) === 'https'
            && preg_match('/^[a-f0-9]{64}$/', (string) ($release['sha256'] ?? '')) === 1
            && is_int($release['size'] ?? null) && $release['size'] > 0;
    }

    private static function canonical_json($value): string
    {
        $normalized = self::canonicalize($value);
        return (string) wp_json_encode($normalized, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }

    private static function canonicalize($value)
    {
        if (!is_array($value)) {
            return $value;
        }
        if (array_keys($value) !== range(0, count($value) - 1)) {
            ksort($value, SORT_STRING);
        }
        foreach ($value as $key => $item) {
            $value[$key] = self::canonicalize($item);
        }
        return $value;
    }
}
