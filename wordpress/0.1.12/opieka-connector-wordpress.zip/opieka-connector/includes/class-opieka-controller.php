<?php

defined('ABSPATH') || exit;
require_once __DIR__ . '/class-opieka-update-diagnostics.php';
require_once __DIR__ . '/class-opieka-update-keys.php';

final class Opieka_Connector_Controller extends WP_REST_Controller
{
    protected $namespace = 'opieka/v1';
    private $updateSkin;

    public function register_routes()
    {
        register_rest_route($this->namespace, '/health', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'health'),
            'permission_callback' => static function (WP_REST_Request $request) {
                return Opieka_Connector_Auth::authorize($request, 'read');
            },
        ));
        register_rest_route($this->namespace, '/inventory', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'inventory'),
            'permission_callback' => static function (WP_REST_Request $request) {
                return Opieka_Connector_Auth::authorize($request, 'read');
            },
        ));
        register_rest_route($this->namespace, '/inventory/cached', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'inventory_cached'),
            'permission_callback' => static function (WP_REST_Request $request) {
                return Opieka_Connector_Auth::authorize($request, 'read');
            },
        ));
        register_rest_route($this->namespace, '/events', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'events'),
            'permission_callback' => static function (WP_REST_Request $request) {
                return Opieka_Connector_Auth::authorize($request, 'read');
            },
            'args' => array('after' => array('default' => 0, 'sanitize_callback' => 'absint')),
        ));
        register_rest_route($this->namespace, '/diagnostics', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'diagnostics'),
            'permission_callback' => static function (WP_REST_Request $request) {
                return Opieka_Connector_Auth::authorize($request, 'read');
            },
        ));
        register_rest_route($this->namespace, '/updates/refresh', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'refresh_updates'),
            'permission_callback' => static function (WP_REST_Request $request) {
                return Opieka_Connector_Auth::authorize($request, 'read');
            },
        ));
        register_rest_route($this->namespace, '/updates/execute', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'execute_update'),
            'permission_callback' => static function (WP_REST_Request $request) {
                return Opieka_Connector_Auth::authorize($request, 'update');
            },
        ));
        register_rest_route($this->namespace, '/updates/check-keys', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'check_update_keys'),
            'permission_callback' => static function (WP_REST_Request $request) { return Opieka_Connector_Auth::authorize($request, 'read'); },
        ));
    }

    private function envelope(array $data): WP_REST_Response
    {
        return new WP_REST_Response(array_merge(array(
            'protocolVersion' => '1.0',
            'connectorVersion' => OPIEKA_CONNECTOR_VERSION,
            'cms' => 'WordPress',
            'cmsVersion' => get_bloginfo('version'),
            'generatedAt' => gmdate('c'),
        ), $data), 200);
    }

    public function health(): WP_REST_Response
    {
        return $this->envelope(array(
            'status' => 'ok',
            'capabilities' => array('inventory-cached', 'inventory', 'backup-profiles', 'events', 'refresh-updates', 'update-one', 'update-core', 'update-diagnostics', 'update-key-check'),
            'scopes' => array_values((array) get_option('opieka_connector_scopes', array('read'))),
            'keyFingerprint' => substr(hash('sha256', (string) get_option('opieka_connector_secret', '')), 0, 16),
        ));
    }

    public function inventory(): WP_REST_Response
    {
        return $this->inventory_data(true);
    }

    public function inventory_cached(): WP_REST_Response
    {
        return $this->inventory_data(false);
    }

    private function inventory_data(bool $refresh): WP_REST_Response
    {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/update.php';
        if ($refresh) {
            wp_update_plugins();
            wp_update_themes();
            wp_version_check();
        }
        // Reading the raw site options avoids get_site_transient expiry deletion.
        $plugin_updates = $refresh ? get_site_transient('update_plugins') : get_site_option('_site_transient_update_plugins');
        $theme_updates = $refresh ? get_site_transient('update_themes') : get_site_option('_site_transient_update_themes');
        $plugins = array();
        $akeeba_product = null;
        foreach (get_plugins() as $file => $plugin) {
            $offer = is_object($plugin_updates) && isset($plugin_updates->response[$file]) ? $plugin_updates->response[$file] : null;
            $plugins[] = array(
                'componentKey' => 'plugin:' . $file,
                'externalId' => $file,
                'name' => sanitize_text_field((string) ($plugin['Name'] ?? $file)),
                'type' => 'plugin',
                'version' => sanitize_text_field((string) ($plugin['Version'] ?? '')),
                'availableVersion' => $offer ? sanitize_text_field((string) ($offer->new_version ?? '')) : null,
                'updateAvailable' => (bool) $offer,
                'active' => is_plugin_active($file),
                'author' => sanitize_text_field(wp_strip_all_tags((string) ($plugin['AuthorName'] ?? $plugin['Author'] ?? ''))),
            );
            $plugin_name = sanitize_text_field((string) ($plugin['Name'] ?? ''));
            if (stripos($plugin_name, 'akeeba backup') !== false) {
                $is_professional = (bool) preg_match('/\b(?:professional|pro)\b/i', $plugin_name);
                $akeeba_product = array(
                    'name' => $plugin_name,
                    'edition' => $is_professional ? 'professional' : 'core',
                    'version' => sanitize_text_field((string) ($plugin['Version'] ?? '')),
                    'detectionBasis' => $is_professional
                        ? 'Nazwa zainstalowanej wtyczki jednoznacznie wskazuje edycję Professional.'
                        : 'Wykryto Akeeba Backup, ale metadane wtyczki nie potwierdzają edycji Professional.',
                );
            }
        }
        $themes = array();
        foreach (wp_get_themes() as $slug => $theme) {
            $offer = is_object($theme_updates) && isset($theme_updates->response[$slug]) ? $theme_updates->response[$slug] : null;
            $themes[] = array(
                'componentKey' => 'theme:' . $slug,
                'externalId' => $slug,
                'name' => $theme->get('Name') ?: $slug,
                'type' => 'theme',
                'version' => (string) $theme->get('Version'),
                'availableVersion' => $offer ? sanitize_text_field((string) ($offer['new_version'] ?? '')) : null,
                'updateAvailable' => (bool) $offer,
                'active' => get_stylesheet() === $slug || get_template() === $slug,
                'author' => sanitize_text_field(wp_strip_all_tags((string) $theme->get('Author'))),
            );
        }
        $cached_core = $refresh ? null : get_site_option('_site_transient_update_core');
        $core = $refresh ? get_core_updates(array('dismissed' => false)) : (is_object($cached_core) && isset($cached_core->updates) ? $cached_core->updates : array());
        $core_offer = is_array($core) ? current(array_filter($core, static function ($item) {
            return isset($item->response) && $item->response === 'upgrade';
        })) : false;
        global $wpdb;
        $profiles = array();
        $profile_table = '';
        foreach (array($wpdb->prefix . 'ak_profiles', $wpdb->prefix . 'akeebabackup_profiles') as $candidate_table) {
            if (preg_match('/^[A-Za-z0-9_]+$/', $candidate_table)
                && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $candidate_table)) === $candidate_table) {
                $profile_table = $candidate_table;
                break;
            }
        }
        if ($profile_table !== '') {
            $profile_rows = $wpdb->get_results("SELECT id, description FROM `{$profile_table}` ORDER BY id", ARRAY_A); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- trusted table prefix plus fixed allowlisted suffix, validated above.
            foreach ((array) $profile_rows as $profile) {
                $profiles[] = array(
                    'externalId' => (string) absint($profile['id'] ?? 0),
                    'name' => sanitize_text_field((string) ($profile['description'] ?? '')) ?: 'Akeeba profile ' . absint($profile['id'] ?? 0),
                    'isDefault' => absint($profile['id'] ?? 0) === 1,
                );
            }
        }
        return $this->envelope(array(
            'environment' => array(
                'php' => PHP_VERSION,
                'database' => $GLOBALS['wpdb']->db_version(),
                'webServer' => sanitize_text_field((string) ($_SERVER['SERVER_SOFTWARE'] ?? '')),
                'siteUrl' => site_url('/'),
                'homeUrl' => home_url('/'),
                'multisite' => is_multisite(),
            ),
            'core' => array('version' => get_bloginfo('version'), 'availableVersion' => $core_offer ? (string) $core_offer->current : null, 'updateAvailable' => (bool) $core_offer),
            'extensions' => array_merge($plugins, $themes),
            'backup' => array('product' => $akeeba_product, 'profiles' => $profiles),
        ));
    }

    public function events(WP_REST_Request $request): WP_REST_Response
    {
        $after = absint($request->get_param('after'));
        $events = array_values(array_filter((array) get_option('opieka_connector_events', array()), static function ($event) use ($after) {
            return (int) ($event['cursor'] ?? 0) > $after;
        }));
        return $this->envelope(array('events' => array_slice($events, 0, 200), 'nextCursor' => $events ? (int) end($events)['cursor'] : $after));
    }

    public function refresh_updates(): WP_REST_Response
    {
        require_once ABSPATH . 'wp-admin/includes/update.php';
        wp_update_plugins();
        wp_update_themes();
        wp_version_check();
        self::record_event('updates.refreshed', array());
        return $this->envelope(array('status' => 'completed'));
    }

    public function check_update_keys(WP_REST_Request $request)
    {
        $parameters = $request->get_json_params();
        if (!is_array($parameters) || array_diff(array_keys($parameters), array('offset','limit','expectedListingHash'))) {
            return new WP_Error('invalid-key-check-page', 'Invalid key check parameters.', array('status' => 400));
        }
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        $candidates = array();
        foreach (array('plugin' => get_plugins(), 'theme' => wp_get_themes()) as $kind => $installed) {
            $updates = get_site_option('_site_transient_update_' . ($kind === 'plugin' ? 'plugins' : 'themes'));
            foreach ($installed as $id => $extension) {
                $offer = is_object($updates) ? ($updates->response[$id] ?? $updates->no_update[$id] ?? null) : null;
                $offer = (array) $offer; $url = (string) ($offer['package'] ?? '');
                $configuration = self::package_key_configuration($url);
                $name = $kind === 'plugin' ? (string) ($extension['Name'] ?? $id) : (string) $extension->get('Name');
                $candidates[] = array('public' => array_merge(array('externalId' => $kind . ':' . $id,
                    'name' => Opieka_Update_Diagnostics::safeMessage($name), 'enabled' => true), $configuration), 'url' => $url);
            }
        }
        usort($candidates, static function ($a, $b) { return strcmp($a['public']['externalId'], $b['public']['externalId']); });
        try { return $this->envelope(Opieka_Update_Keys::page($candidates, $parameters, static function ($candidate) {
            return $candidate['url'] !== '' ? self::inspect_package_access($candidate['url']) : array('status' => 'unverified', 'reason' => 'no-offer', 'httpStatus' => null);
        })); } catch (InvalidArgumentException $error) { return new WP_Error('invalid-key-check-page', 'Invalid key check page.', array('status' => 400)); }
        catch (RuntimeException $error) { return new WP_Error('key-check-listing-changed', 'Update sources changed. Read the first page again.', array('status' => 409)); }
    }

    private static function package_key_configuration(string $url): array
    {
        $required = null; $configured = null;
        // The effective native package URL is authoritative. Do not read
        // or guess vendor-specific options, or infer validity from length.
        if (strtolower((string) parse_url($url, PHP_URL_HOST)) === 'api.yootheme.com') {
            $required = true; parse_str((string) parse_url($url, PHP_URL_QUERY), $query);
            foreach (array('key','api_key','apikey','token') as $key) {
                if (isset($query[$key]) && is_string($query[$key]) && trim($query[$key]) !== '') { $configured = true; }
            }
            $args = apply_filters('http_request_args', array('headers' => array()), $url);
            $headers = is_array($args) && is_array($args['headers'] ?? null) ? array_change_key_case($args['headers'], CASE_LOWER) : null;
            if (is_array($headers)) {
                foreach (array('authorization','x-api-key','x-yootheme-key') as $key) {
                    if (isset($headers[$key]) && is_scalar($headers[$key]) && trim((string) $headers[$key]) !== '') { $configured = true; }
                }
                if ($configured !== true && !$query) { $configured = false; }
            }
        }
        return Opieka_Update_Keys::configuration($required, $configured);
    }

    private static function inspect_package_access(string $url): array
    {
        $args = apply_filters('http_request_args', array('headers' => array()), $url);
        if (!is_array($args) || !is_array($args['headers'] ?? array())) {
            return array('status' => 'unverified', 'reason' => 'source-unverified', 'httpStatus' => null);
        }
        return Opieka_Update_Keys::probe($url, $args['headers'] ?? array());
    }

    public function diagnostics(): WP_REST_Response
    {
        $rows = (array) get_option('opieka_connector_diagnostics', array());
        $cutoff = time() - Opieka_Update_Diagnostics::RETENTION_DAYS * 86400;
        $rows = array_values(array_filter($rows, static function ($row) use ($cutoff) {
            return is_array($row) && strtotime((string) ($row['occurredAt'] ?? '')) >= $cutoff;
        }));
        return $this->envelope(array('diagnosticVersion' => Opieka_Update_Diagnostics::VERSION,
            'entries' => array_slice($rows, -200), 'windowLimit' => 200,
            'retentionDays' => 14, 'hasMore' => count($rows) > 200));
    }

    private static function record_diagnostic(array $row)
    {
        $cutoff = time() - Opieka_Update_Diagnostics::RETENTION_DAYS * 86400;
        $rows = array_values(array_filter((array) get_option('opieka_connector_diagnostics', array()), static function ($item) use ($cutoff) {
            return is_array($item) && strtotime((string) ($item['occurredAt'] ?? '')) >= $cutoff;
        }));
        $rows[] = $row;
        update_option('opieka_connector_diagnostics', array_slice($rows, -400), false);
    }

    public function execute_update(WP_REST_Request $request)
    {
        $payload = (array) $request->get_json_params();
        $id = (string) ($payload['operationId'] ?? '');
        if (!preg_match('/^[A-Za-z0-9._:-]{12,120}$/D', $id)) {
            return $this->perform_update($request, null);
        }
        $diagnostic = new Opieka_Update_Diagnostics($id, (string) ($payload['componentKey'] ?? ''), static function ($row) { self::record_diagnostic($row); });
        $this->updateSkin = null;
        $download = static function ($reply, $url) use ($diagnostic) { $diagnostic->phase('download'); return $reply; };
        $unpack = static function ($source) use ($diagnostic) { $diagnostic->phase('unpack'); return $source; };
        $install = static function ($reply) use ($diagnostic) { $diagnostic->phase('install'); return $reply; };
        $verify = static function ($reply) use ($diagnostic) { $diagnostic->phase('post-install-verification'); return $reply; };
        $http = static function ($response, $context, $class, $args, $url) use ($diagnostic) {
            if ($context === 'response') {
                $diagnostic->http(is_wp_error($response) ? null : (int) wp_remote_retrieve_response_code($response), $url,
                    is_wp_error($response) ? $response->get_error_code() : '');
            }
        };
        add_filter('upgrader_pre_download', $download, PHP_INT_MAX, 2);
        add_filter('upgrader_source_selection', $unpack, PHP_INT_MAX, 1);
        add_filter('upgrader_pre_install', $install, PHP_INT_MAX, 1);
        add_filter('upgrader_post_install', $verify, PHP_INT_MAX, 1);
        add_action('http_api_debug', $http, PHP_INT_MAX, 5);
        try {
            $result = $this->perform_update($request, $diagnostic);
            if (is_wp_error($result)) {
                $messages = $this->updateSkin && method_exists($this->updateSkin, 'get_upgrade_messages') ? $this->updateSkin->get_upgrade_messages() : [];
                $message = $result->get_error_message() . ' ' . implode(' ', array_slice((array) $messages, -3));
                $diagnostic->finish(strpos($result->get_error_code(), 'conflict') !== false ? 'rejected' : 'failed', $result->get_error_code(), $message);
            } else {
                $data = $result instanceof WP_REST_Response ? $result->get_data() : [];
                $completed = in_array($data['status'] ?? '', ['completed', 'idempotent-replay'], true);
                $diagnostic->finish($completed ? 'completed' : 'failed', $completed ? '' : 'native_result_unconfirmed');
            }
            return $result;
        } catch (\Throwable $error) {
            $diagnostic->finish('failed', 'php_exception', 'PHP exception: ' . get_class($error));
            throw $error;
        } finally {
            remove_filter('upgrader_pre_download', $download, PHP_INT_MAX);
            remove_filter('upgrader_source_selection', $unpack, PHP_INT_MAX);
            remove_filter('upgrader_pre_install', $install, PHP_INT_MAX);
            remove_filter('upgrader_post_install', $verify, PHP_INT_MAX);
            remove_action('http_api_debug', $http, PHP_INT_MAX);
        }
    }

    private function perform_update(WP_REST_Request $request, $diagnostic)
    {
        $payload = $request->get_json_params();
        $operation_id = sanitize_text_field((string) ($payload['operationId'] ?? ''));
        $kind = sanitize_key((string) ($payload['kind'] ?? ''));
        $component_key = sanitize_text_field((string) ($payload['componentKey'] ?? ''));
        $expected = sanitize_text_field((string) ($payload['expectedCurrentVersion'] ?? ''));
        $target = sanitize_text_field((string) ($payload['targetVersion'] ?? ''));
        if (!preg_match('/^[A-Za-z0-9._:-]{12,120}$/', $operation_id)
            || !in_array($kind, array('plugin', 'theme', 'core'), true)
            || $component_key === '' || $expected === '' || $target === ''
            || !version_compare($target, $expected, '>')) {
            return new WP_Error('opieka_update_invalid', 'Invalid frozen update operation.', array('status' => 400));
        }
        $operations = (array) get_option('opieka_connector_operations', array());
        if (isset($operations[$operation_id])) {
            return $this->envelope(array('status' => 'idempotent-replay', 'operation' => $operations[$operation_id]));
        }
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/update.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        if (is_readable(ABSPATH . 'wp-admin/includes/class-core-upgrader.php')) {
            require_once ABSPATH . 'wp-admin/includes/class-core-upgrader.php';
        }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        if ($diagnostic) { $diagnostic->phase('metadata-refresh'); }
        wp_update_plugins();
        wp_update_themes();
        wp_version_check();
        if ($diagnostic) { $diagnostic->phase('live-state-check'); }
        $result = null;
        if ($kind === 'plugin') {
            $file = strpos($component_key, 'plugin:') === 0 ? substr($component_key, 7) : $component_key;
            $plugins = get_plugins();
            $updates = get_site_transient('update_plugins');
            $current = sanitize_text_field((string) ($plugins[$file]['Version'] ?? ''));
            $offered = is_object($updates) && isset($updates->response[$file]) ? sanitize_text_field((string) ($updates->response[$file]->new_version ?? '')) : '';
            if ($current !== $expected || $offered !== $target) {
                return new WP_Error('opieka_update_conflict', 'Live plugin state differs from the approved operation.', array('status' => 409, 'currentVersion' => $current, 'offeredVersion' => $offered));
            }
            // The single-plugin upgrade() path deactivates the plugin and
            // expects a browser iframe to reactivate it. The native bulk path
            // preserves activation; pass exactly the one approved plugin.
            $keyError = self::update_access_error((string) ($updates->response[$file]->package ?? ''));
            if ($keyError) { return $keyError; }
            if ($diagnostic) { $diagnostic->phase('filesystem'); }
            $this->updateSkin = new Automatic_Upgrader_Skin();
            $results = (new Plugin_Upgrader($this->updateSkin))->bulk_upgrade(array($file), array('clear_update_cache' => true));
            $result = is_array($results) ? ($results[$file] ?? false) : false;
            if (is_array($result)) {
                $result = true;
            }
        } elseif ($kind === 'theme') {
            $slug = strpos($component_key, 'theme:') === 0 ? substr($component_key, 6) : $component_key;
            $theme = wp_get_theme($slug);
            $updates = get_site_transient('update_themes');
            $current = $theme->exists() ? (string) $theme->get('Version') : '';
            $offered = is_object($updates) && isset($updates->response[$slug]) ? sanitize_text_field((string) ($updates->response[$slug]['new_version'] ?? '')) : '';
            if ($current !== $expected || $offered !== $target) {
                return new WP_Error('opieka_update_conflict', 'Live theme state differs from the approved operation.', array('status' => 409, 'currentVersion' => $current, 'offeredVersion' => $offered));
            }
            $keyError = self::update_access_error((string) ($updates->response[$slug]['package'] ?? ''));
            if ($keyError) { return $keyError; }
            if ($diagnostic) { $diagnostic->phase('filesystem'); }
            $this->updateSkin = new Automatic_Upgrader_Skin();
            $result = (new Theme_Upgrader($this->updateSkin))->upgrade($slug, array('clear_update_cache' => true));
        } else {
            if ($component_key !== 'core:wordpress') {
                return new WP_Error('opieka_update_invalid', 'Invalid WordPress Core identity.', array('status' => 400));
            }
            $current = self::installed_core_version();
            if ($current === $target) {
                $result = true;
            } elseif ($current !== $expected) {
                return new WP_Error('opieka_update_conflict', 'Live WordPress Core version differs from the approved operation.', array('status' => 409, 'currentVersion' => $current));
            }
            if (explode('.', $expected)[0] !== explode('.', $target)[0]) {
                return new WP_Error('opieka_manual_migration_required', 'Core release-line migrations require a human-controlled process.', array('status' => 409));
            }
            if ($result !== true) {
                $offers = get_core_updates(array('dismissed' => false));
                $matching = array_values(array_filter(is_array($offers) ? $offers : array(), static function ($offer) use ($target) {
                    return isset($offer->response, $offer->current)
                        && $offer->response === 'upgrade'
                        && (string) $offer->current === $target;
                }));
                if (count($matching) !== 1) {
                    return new WP_Error('opieka_update_conflict', 'The live WordPress Core offer does not uniquely match the approved target.', array('status' => 409, 'candidateCount' => count($matching)));
                }
                ignore_user_abort(true);
                if (function_exists('set_time_limit')) {
                    @set_time_limit(900);
                }
                if ($diagnostic) { $diagnostic->phase('filesystem'); }
                $this->updateSkin = new Automatic_Upgrader_Skin();
                $upgraded = (new Core_Upgrader($this->updateSkin))->upgrade($matching[0], array(
                    'pre_check_md5' => true,
                    'attempt_rollback' => true,
                ));
                if (is_wp_error($upgraded)) {
                    return new WP_Error('opieka_update_failed', Opieka_Update_Diagnostics::safeMessage($upgraded->get_error_message()), array('status' => 422));
                }
                $version_after = self::installed_core_version();
                $result = is_string($upgraded) && $upgraded === $target && $version_after === $target;
            }
        }
        if (is_wp_error($result)) {
            return new WP_Error('opieka_update_failed', Opieka_Update_Diagnostics::safeMessage($result->get_error_message()), array('status' => 422));
        }
        if ($result !== true) {
            // Theme_Upgrader can return false while its skin holds the native
            // download error. Preserve its explanation without download URLs.
            $messages = $this->updateSkin ? (array) $this->updateSkin->get_upgrade_messages() : array();
            $detail = Opieka_Update_Diagnostics::safeMessage(implode(' ', array_slice($messages, -3)));
            return new WP_Error('opieka_update_unconfirmed', $detail ?: 'WordPress did not confirm the update.', array('status' => 422));
        }
        if ($diagnostic) { $diagnostic->phase('post-install-verification'); }
        $record = array('operationId' => $operation_id, 'kind' => $kind, 'componentKey' => $component_key, 'fromVersion' => $expected, 'toVersion' => $target, 'status' => 'completed', 'completedAt' => gmdate('c'));
        $operations[$operation_id] = $record;
        if (count($operations) > 100) {
            $operations = array_slice($operations, -100, null, true);
        }
        update_option('opieka_connector_operations', $operations, false);
        self::record_event('update.completed', $record);
        return $this->envelope(array('status' => 'completed', 'operation' => $record));
    }

    private static function update_access_error(string $url)
    {
        $check = self::package_key_configuration($url);
        if ($check['status'] === 'missing') {
            return new WP_Error('update-key-missing', 'Brak wymaganego klucza pobierania. Uzupełnij klucz i ponów audyt.', array('status' => 422, 'mutationStarted' => false));
        }
        $check = self::inspect_package_access($url);
        if ($check['status'] === 'rejected') {
            return new WP_Error('update-key-rejected', 'Serwer aktualizacji odrzucił autoryzację (HTTP 401). Sprawdź klucz i uprawnienie pobierania, a następnie ponów audyt.', array('status' => 422, 'mutationStarted' => false));
        }
        if ($check['status'] === 'denied') {
            return new WP_Error('update-source-access-denied', 'Serwer aktualizacji zabronił pobierania (HTTP 403). Sprawdź uprawnienie i reguły dostępu.', array('status' => 422, 'mutationStarted' => false));
        }
        return null;
    }

    private static function installed_core_version()
    {
        $wp_version = '';
        $version_file = ABSPATH . WPINC . '/version.php';
        if (is_readable($version_file)) {
            require $version_file;
        }
        return sanitize_text_field((string) $wp_version);
    }

    public static function record_event(string $type, array $data)
    {
        $events = (array) get_option('opieka_connector_events', array());
        $cursor = $events ? ((int) end($events)['cursor'] + 1) : 1;
        $events[] = array('cursor' => $cursor, 'type' => sanitize_key(str_replace('.', '-', $type)), 'occurredAt' => gmdate('c'), 'data' => $data);
        update_option('opieka_connector_events', array_slice($events, -200), false);
    }
}
