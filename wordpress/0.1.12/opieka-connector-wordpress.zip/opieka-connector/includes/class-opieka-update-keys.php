<?php
/** Read-only download access checks. Never returns URLs, headers or key values. */
final class Opieka_Update_Keys
{
    public static function configuration($required, $configured): array
    {
        return ['required' => $required, 'configured' => $configured,
            'status' => $required === true && $configured === false ? 'missing' : 'unverified',
            'reason' => $required === true && $configured === false ? 'key-missing' : 'no-offer',
            'httpStatus' => null];
    }

    public static function classify(int $status, string $prefix): array
    {
        $result = ['status' => 'unverified', 'reason' => 'download-unverified', 'httpStatus' => $status ?: null];
        if ($status === 401) { $result['status'] = 'rejected'; $result['reason'] = 'authorization-rejected'; }
        elseif ($status === 403) { $result['status'] = 'denied'; $result['reason'] = 'access-denied'; }
        elseif (in_array($status, [200, 206], true) && (substr($prefix, 0, 4) === "PK\x03\x04" || substr($prefix, 0, 2) === "\x1f\x8b")) {
            $result['status'] = 'accepted'; $result['reason'] = 'package-access-confirmed';
        } elseif ($status >= 300 && $status < 400) { $result['reason'] = 'redirect-unverified'; }
        elseif ($status >= 500 || $status === 429) { $result['reason'] = 'server-unavailable'; }
        return $result;
    }

    public static function publicTarget(string $url, $resolver = null)
    {
        $parts = parse_url(html_entity_decode($url, ENT_QUOTES, 'UTF-8'));
        if (!is_array($parts) || ($parts['scheme'] ?? '') !== 'https' || empty($parts['host'])
            || isset($parts['user']) || isset($parts['pass']) || isset($parts['fragment']) || ($parts['port'] ?? 443) !== 443
            || preg_match('/[\x00-\x20\x7f]/', $url)) { return null; }
        $host = strtolower($parts['host']);
        if (!preg_match('/^[a-z0-9.-]{1,253}$/D', $host)) { return null; }
        $addresses = $resolver ? $resolver($host) : array_column((array) @dns_get_record($host, DNS_A), 'ip');
        if (!$addresses) { return null; }
        foreach ($addresses as $ip) {
            if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)
                || preg_match('/^(?:0\.|127\.|169\.254\.|100\.(?:6[4-9]|[7-9][0-9]|1[01][0-9]|12[0-7])\.|192\.0\.0\.|198\.(?:18|19)\.|2(?:2[4-9]|[3-5][0-9])\.)/', $ip)) { return null; }
        }
        return [$host, $addresses[0]];
    }

    /** One HTTPS GET, 4 KiB maximum, 8 seconds; redirect/auth forwarding disabled. */
    public static function probe(string $url, array $headers = []): array
    {
        $response = self::fetch($url, $headers, 4096);
        return $response === null ? ['status' => 'unverified', 'reason' => 'transport-unavailable', 'httpStatus' => null] : self::classify($response['status'], $response['body']);
    }

    /** Internal bounded bytes only; callers must never include these in API output. */
    public static function fetch(string $url, array $headers, int $limit)
    {
        if (!function_exists('curl_init')) { return null; }
        $target = self::publicTarget($url);
        if (!$target) { return null; }
        $safeHeaders = ['Range: bytes=0-' . ($limit - 1), 'Accept-Encoding: identity'];
        foreach ($headers as $name => $value) {
            if (!is_string($name) || !preg_match('/^[A-Za-z0-9-]+$/D', $name) || !is_scalar($value)
                || preg_match('/[\r\n\x00]/', (string) $value) || in_array(strtolower($name), ['host','range','accept-encoding'], true)) { continue; }
            $safeHeaders[] = $name . ': ' . (string) $value;
        }
        $body = ''; $handle = curl_init(html_entity_decode($url, ENT_QUOTES, 'UTF-8'));
        curl_setopt_array($handle, [CURLOPT_FOLLOWLOCATION => false, CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
            CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2, CURLOPT_CONNECTTIMEOUT => 3, CURLOPT_TIMEOUT => 8,
            CURLOPT_RESOLVE => [$target[0] . ':443:' . $target[1]], CURLOPT_HTTPHEADER => $safeHeaders,
            CURLOPT_USERAGENT => 'Opieka-Connector-Update-Keys/1.0', CURLOPT_PROXY => '',
            CURLOPT_WRITEFUNCTION => static function ($handle, $chunk) use (&$body, $limit) {
                $body .= substr($chunk, 0, max(0, $limit - strlen($body)));
                return strlen($body) >= $limit ? 0 : strlen($chunk);
            }]);
        curl_exec($handle); $error = curl_errno($handle); $status = (int) curl_getinfo($handle, CURLINFO_RESPONSE_CODE); curl_close($handle);
        if ($error && !($error === CURLE_WRITE_ERROR && strlen($body) === $limit)) { return null; }
        return ['status' => $status, 'body' => $body, 'truncated' => $error === CURLE_WRITE_ERROR];
    }

    public static function page(array $candidates, array $parameters, $inspect): array
    {
        $offset = $parameters['offset'] ?? 0; $limit = $parameters['limit'] ?? 3; $expected = $parameters['expectedListingHash'] ?? '';
        if (!is_int($offset) || !is_int($limit) || $offset < 0 || $offset > 1000 || $limit < 1 || $limit > 3
            || !is_string($expected) || !preg_match('/^(?:|[a-f0-9]{64})$/D', $expected) || ($offset > 0 && $expected === '')) {
            throw new InvalidArgumentException('invalid-key-check-page');
        }
        $public = array_map(static function ($candidate) { return $candidate['public']; }, $candidates);
        $hash = hash('sha256', json_encode($public, JSON_UNESCAPED_SLASHES));
        if ($expected !== '' && !hash_equals($hash, $expected)) { throw new RuntimeException('key-check-listing-changed'); }
        $total = count($candidates);
        if ($total > 1000 || $offset > $total) { throw new InvalidArgumentException('invalid-key-check-page'); }
        $items = [];
        foreach (array_slice($candidates, $offset, $limit) as $candidate) {
            $item = $candidate['public'];
            if ($item['status'] !== 'missing' && $item['enabled']) {
                try { $item = array_merge($item, $inspect($candidate)); }
                catch (Throwable $error) { $item['status'] = 'unverified'; $item['reason'] = 'source-unverified'; }
            } elseif (!$item['enabled']) { $item['status'] = 'unverified'; $item['reason'] = 'source-disabled'; }
            $items[] = $item;
        }
        $next = $offset + count($items);
        return ['keyCheckVersion' => '1.0', 'items' => $items, 'offset' => $offset, 'total' => $total,
            'nextOffset' => $next < $total ? $next : null, 'listingHash' => $hash];
    }
}
