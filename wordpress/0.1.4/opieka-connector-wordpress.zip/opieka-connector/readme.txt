=== Opieka Technical Connector ===
Contributors: indico
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 0.1.4
Tested up to: 7.1
License: GPLv2 or later

Signed inventory, event and explicitly approved single-component update API for the Opieka techniczna system.

The plugin does not expose file access, SQL, arbitrary PHP execution or arbitrary package URLs. Configure the generated shared secret in Bitwarden Secrets Manager before enabling update scope.

Compatibility tested with WordPress 6.0.3 / PHP 7.4 and WordPress 7.1 / PHP 8.3. CMS requirements still apply. HTTPS, signed requests, nonce replay protection and explicit update scope remain required.

0.1.4 preserves event history on reactivation, loads filesystem functions for REST updates and uses the native one-item bulk upgrade path to preserve plugin activation.
