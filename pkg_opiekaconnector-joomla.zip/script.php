<?php

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Installer\InstallerScriptInterface;
use Joomla\Database\DatabaseInterface;
use Joomla\Database\ParameterType;
use Joomla\Registry\Registry;

return new class () implements InstallerScriptInterface {
    public function install(InstallerAdapter $parent): bool
    {
        return true;
    }

    public function update(InstallerAdapter $parent): bool
    {
        return true;
    }

    public function uninstall(InstallerAdapter $parent): bool
    {
        return true;
    }

    public function preflight(string $type, InstallerAdapter $parent): bool
    {
        return true;
    }

    public function postflight(string $type, InstallerAdapter $parent): bool
    {
        if ($type === 'uninstall') {
            return true;
        }

        try {
            $db = Factory::getContainer()->get(DatabaseInterface::class);
            $this->ensureSchema($db);
            $pluginType = 'plugin';
            $systemFolder = 'system';
            $connectorElement = 'opiekaconnector';
            $query = $db->getQuery(true)
                ->select([$db->quoteName('extension_id'), $db->quoteName('params')])
                ->from($db->quoteName('#__extensions'))
                ->where($db->quoteName('type') . ' = :type')
                ->where($db->quoteName('folder') . ' = :folder')
                ->where($db->quoteName('element') . ' = :element')
                ->bind(':type', $pluginType)
                ->bind(':folder', $systemFolder)
                ->bind(':element', $connectorElement);
            $extension = $db->setQuery($query)->loadObject();
            if (!$extension) {
                throw new RuntimeException('The System - Opieka Connector plugin record was not created.');
            }

            $pluginType = 'plugin';
            $connectorElement = 'opiekaconnector';
            $pluginFolders = ['system', 'webservices'];
            $enable = $db->getQuery(true)
                ->update($db->quoteName('#__extensions'))
                ->set($db->quoteName('enabled') . ' = 1')
                ->where($db->quoteName('type') . ' = :enableType')
                ->where($db->quoteName('element') . ' = :enableElement')
                ->whereIn($db->quoteName('folder'), $pluginFolders, ParameterType::STRING)
                ->bind(':enableType', $pluginType)
                ->bind(':enableElement', $connectorElement);
            $db->setQuery($enable)->execute();

            $params = new Registry((string) $extension->params);
            $keyId = trim((string) $params->get('key_id', ''));
            $secret = (string) $params->get('secret', '');
            $changed = false;
            if ($keyId === '') {
                $params->set('key_id', 'opk_' . bin2hex(random_bytes(12)));
                $changed = true;
            }
            if (strlen($secret) < 32) {
                $params->set('secret', rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '='));
                $changed = true;
            }
            if (!$params->get('scopes')) {
                $params->set('scopes', ['read']);
                $changed = true;
            }
            if (!$changed) return true;

            $extensionId = (int) $extension->extension_id;
            $encodedParams = $params->toString('JSON');
            $update = $db->getQuery(true)
                ->update($db->quoteName('#__extensions'))
                ->set($db->quoteName('params') . ' = :params')
                ->where($db->quoteName('extension_id') . ' = :extensionId')
                ->bind(':params', $encodedParams)
                ->bind(':extensionId', $extensionId, ParameterType::INTEGER);
            $db->setQuery($update)->execute();

            return true;
        } catch (Throwable $error) {
            Factory::getApplication()->enqueueMessage(
                'Opieka Connector could not initialise its API credentials: ' . $error->getMessage(),
                'error'
            );

            return false;
        }
    }

    private function ensureSchema(DatabaseInterface $db): void
    {
        $queries = [
            "CREATE TABLE IF NOT EXISTS `#__opiekaconnector_events` (
                `id` bigint unsigned NOT NULL AUTO_INCREMENT,
                `event_type` varchar(100) NOT NULL,
                `payload` mediumtext NOT NULL,
                `created_at` datetime NOT NULL,
                PRIMARY KEY (`id`),
                KEY `idx_opieka_event_created` (`created_at`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS `#__opiekaconnector_operations` (
                `operation_id` varchar(120) NOT NULL,
                `component_key` varchar(255) NOT NULL,
                `result` mediumtext NOT NULL,
                `created_at` datetime NOT NULL,
                PRIMARY KEY (`operation_id`),
                KEY `idx_opieka_operation_created` (`created_at`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS `#__opiekaconnector_nonces` (
                `nonce_hash` char(64) NOT NULL,
                `expires_at` datetime NOT NULL,
                PRIMARY KEY (`nonce_hash`),
                KEY `idx_opieka_nonce_expires` (`expires_at`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci",
        ];

        foreach ($queries as $query) {
            $db->setQuery($query)->execute();
        }
    }
};
